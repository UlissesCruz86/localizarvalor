package com.example.main;

public class LocalizarValorTeste {

    public static void main(String[] args) {
        Main.main(args);
    }
}
